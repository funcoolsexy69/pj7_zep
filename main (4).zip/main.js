// let spartan = App.loadSpritesheet('spartan.png', 64, 96{
//     left: [0, 1, 2, 3],
//     up: [0],
//     down: [0],
//     right: [0, 1, 2, 3],
// }, 8);

App.onSay.Add(function (player, text) {
    App.showCenterLabel(text);
})

App.onJoinPlayer.Add(function (player) {

    // player.sprite = spartan;
    // player.sendUpdated();

})