// let spartan = App.loadSpritesheet('spartan.png', 64, 96{
//     left: [0, 1, 2, 3],
//     up: [0],
//     down: [0],
//     right: [0, 1, 2, 3],
// }, 8);

App.onSay.Add(function (player, text) {
    let message = player.name + '님이' + text + '(이)라고 말했습니다.';
    App.showCenterLabel(message);
})

